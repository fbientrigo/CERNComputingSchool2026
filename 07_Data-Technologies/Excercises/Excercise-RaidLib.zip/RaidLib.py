#!/usr/bin/python3

#!/usr/bin/env python

import sys, os, hashlib

DefaultBlockSize = '10240'

ErrorCorrectionData = {}
ErrorCorrectionData['Raid0'] = {
    'DataStripes'    : ['P1', 'P2'],
    'ErrCorrStripes' : [],
    'WriteRotate'    : False,
    'RuleMatrix'     : [
                       ]    
    }
ErrorCorrectionData['Raid1'] = {
    'DataStripes'    : ['P1'],
    'ErrCorrStripes' : ['PY'],
    'WriteRotate'    : False,
    'RuleMatrix'     : [
                            ['P1', 'PY']
                       ]    
    }
ErrorCorrectionData['Raid10'] = {
    'DataStripes'    : ['P1', 'P2'],
    'ErrCorrStripes' : ['PX', 'PY'],
    'WriteRotate'    : False,
    'RuleMatrix'     : [
                            ['P1', 'PX'],
                            ['P2', 'PY']
                       ]    
    }
ErrorCorrectionData['Raid4x3'] = {
    'DataStripes'    : ['P1', 'P2'],
    'ErrCorrStripes' : ['PY'],
    'WriteRotate'    : False,
    'RuleMatrix'     : [
                            ['P1', 'P2', 'PY']
                       ]    
    }
ErrorCorrectionData['Raid5x3'] = {
    'DataStripes'    : ['P1', 'P2'],
    'ErrCorrStripes' : ['PY'],
    'WriteRotate'    : True,
    'RuleMatrix'     : [
                            ['P1', 'P2', 'PY']
                       ]    
    }
ErrorCorrectionData['Raid4x6'] = {
    'DataStripes'    : ['P1', 'P2', 'P3', 'P4', 'P5'],
    'ErrCorrStripes' : ['PY'],
    'WriteRotate'    : False,
    'RuleMatrix'     : [
                            ['P1', 'P2', 'P3', 'P4', 'P5', 'PY']
                       ]    
    }
ErrorCorrectionData['Raid5x6'] = {
    'DataStripes'    : ['P1', 'P2', 'P3', 'P4', 'P5'],
    'ErrCorrStripes' : ['PY'],
    'WriteRotate'    : True,
    'RuleMatrix'     : [
                            ['P1', 'P2', 'P3', 'P4', 'P5', 'PY']
                       ]    
    }
ErrorCorrectionData['RaidDP'] = {
    'DataStripes'    : ['D1a', 'D2a', 'D3a', 'D4a', 'D1b', 'D2b', 'D3b', 'D4b', 'D1c', 'D2c', 'D3c', 'D4c', 'D1d', 'D2d', 'D3d', 'D4d'],
    'ErrCorrStripes' : ['PYa', 'PYb', 'PYc', 'PYd', 'DPa', 'DPb', 'DPc', 'DPd'],
    'WriteRotate'    : False,
    'RuleMatrix'     : [
                            ['D1a', 'D2a', 'D3a', 'D4a', 'PYa'],
                            ['D1b', 'D2b', 'D3b', 'D4b', 'PYb'], 
                            ['D1c', 'D2c', 'D3c', 'D4c', 'PYc'],
                            ['D1d', 'D2d', 'D3d', 'D4d', 'PYd'],
                            ['D1a', 'D2b', 'D3c', 'D4d', 'DPa'],
                            ['D2a', 'D3b', 'D4c', 'PYd', 'DPb'],
                            ['D3a', 'D4b', 'PYc', 'D1d', 'DPc'],
                            ['D4a', 'PYb', 'D1c', 'D2d', 'DPd']
                       ]    
    }
    
ErrorCorrectionData['RaidDPR'] = {
    'DataStripes'    : ['D1a', 'D2a', 'D3a', 'D4a', 'D1b', 'D2b', 'D3b', 'D4b', 'D1c', 'D2c', 'D3c', 'D4c', 'D1d', 'D2d', 'D3d', 'D4d'],
    'ErrCorrStripes' : ['PYa', 'PYb', 'PYc', 'PYd', 'DPa', 'DPb', 'DPc', 'DPd'],
    'WriteRotate'    : True,
    'RuleMatrix'     : [
                            ['D1a', 'D2a', 'D3a', 'D4a', 'PYa'],
                            ['D1b', 'D2b', 'D3b', 'D4b', 'PYb'], 
                            ['D1c', 'D2c', 'D3c', 'D4c', 'PYc'],
                            ['D1d', 'D2d', 'D3d', 'D4d', 'PYd'],
                            ['D1a', 'D2b', 'D3c', 'D4d', 'DPa'],
                            ['D2a', 'D3b', 'D4c', 'PYd', 'DPb'],
                            ['D3a', 'D4b', 'PYc', 'D1d', 'DPc'],
                            ['D4a', 'PYb', 'D1c', 'D2d', 'DPd']
                       ]    
    }
    
ErrorCorrectionData['LDPC3'] = {
    'DataStripes'    : ['D1', 'D2', 'D3', 'D4', 'D5', 'D6', 'D7', 'D8'],
    'ErrCorrStripes' : ['D9', 'DA', 'DB', 'DC', 'DD', 'DE'],
    'WriteRotate'    : False, #10    11    12    13
    'RuleMatrix'     : [
                            ['D9', 'D1', 'D2', 'D3', 'DA'],
                            ['DA', 'D2', 'D3', 'D4'], 
                            ['DB', 'D3', 'D4', 'D5'], 
                            ['DC', 'D4', 'D5', 'D6'], 
                            ['DD', 'D5', 'D6', 'D7'], 
                            ['DE', 'D6', 'D7', 'D8', 'DD']
                       ]    
    }
ErrorCorrectionData['LDPC4'] = {
    'DataStripes'    : ['D1', 'D2', 'D3', 'D4', 'D5', 'D6', 'D7', 'D8'],
    'ErrCorrStripes' : ['D9', 'DA', 'DB', 'DC', 'DD', 'DE'],
    'WriteRotate'    : False, #10    11    12    13
    'RuleMatrix'     : [
                            ['D9', 'D1', 'D2', 'D3', 'D4'],
                            ['DA', 'D2', 'D3', 'D4', 'D5'], 
                            ['DB', 'D3', 'D4', 'D5', 'D6'], 
                            ['DC', 'D4', 'D5', 'D6', 'D7'], 
                            ['DD', 'D5', 'D6', 'D7', 'D8'], 
                            ['DE', 'D6', 'D7', 'D8', 'D5']
                       ]    
    }
ErrorCorrectionData['LDPC'] = {
    'DataStripes'    : ['D0', 'D1', 'D2', 'D3', 'D4', 'D5', 'D6', 'D7'],
    'ErrCorrStripes' : ['D8', 'D9', 'DA', 'DB', 'DC', 'DD'],
    'WriteRotate'    : False,    #   10    11    12    13
    'RuleMatrix'     : [
                            ['D9', 'D0', 'D1', 'D2', 'D4'],
                            ['DC', 'D0', 'D1', 'D3', 'D5'], 
                            ['D8', 'D0', 'D2', 'D5', 'D7'], 
                            ['DB', 'D2', 'D3', 'D4', 'D6'], 
                            ['DA', 'D3', 'D4', 'D5', 'D6'], 
                            ['DD', 'D1', 'D6', 'D7'] 
                       ]    
    }
ErrorCorrectionData['LDPCR'] = {
    'DataStripes'    : ['D0', 'D1', 'D2', 'D3', 'D4', 'D5', 'D6', 'D7'],
    'ErrCorrStripes' : ['D8', 'D9', 'DA', 'DB', 'DC', 'DD'],
    'WriteRotate'    : True,    #   10    11    12    13
    'RuleMatrix'     : [
                            ['D9', 'D0', 'D1', 'D2', 'D4'],
                            ['DC', 'D0', 'D1', 'D3', 'D5'], 
                            ['D8', 'D0', 'D2', 'D5', 'D7'], 
                            ['DB', 'D2', 'D3', 'D4', 'D6'], 
                            ['DA', 'D3', 'D4', 'D5', 'D6'], 
                            ['DD', 'D1', 'D6', 'D7'] 
                       ]    
    }

# def sxor(s1,s2):    
    # # convert strings to a list of character pair tuples
    # # go through each tuple, converting them to ASCII code (ord)
    # # perform exclusive or on the ASCII code
    # # then convert the result back to ASCII (chr)
    # # merge the resulting array of characters as a string
    # return ''.join(chr(ord(a) ^ ord(b)) for a,b in zip(s1,s2))

# def strxor (s0, s1):
  # l = [ chr ( ord (a) ^ ord (b) ) for a,b in zip (s0, s1) ]
  # return ''.join (l)

def md5sum(filename):
    hash = hashlib.md5()
    try:
        with open(filename, "rb") as f:
            for chunk in iter(lambda: f.read(128 * hash.block_size), b""):
                hash.update(chunk)
        return hash.hexdigest()
    except:
        return '******file*does*not*exist*!*****'

def sha1sum(filename):
    hash = hashlib.sha1()
    try:
        with open(filename, "rb") as f:
            for chunk in iter(lambda: f.read(128 * hash.block_size), b""):
                hash.update(chunk)
        return hash.hexdigest()
    except:
        return '*********file*does*not*exist*!**********'

def md5string(string):
    return hashlib.md5(string).hexdigest()

def sha1string(string):
    return hashlib.sha1(string).hexdigest()
    
def RebuildStripe (block, Stripe, Buildpattern):

    Iteration = 1
    
    for StripeToXor in Buildpattern:
        if StripeToXor == Stripe:
            continue
        if Iteration == 1:
            block[Stripe][:] = block[StripeToXor]        
        else:
            for i in range(len(block[StripeToXor])):
                block[Stripe][i] = block[Stripe][i] ^ block[StripeToXor][i]
        Iteration += 1
    
def RaidGenRebuild (block, StripeToBuildList, RuleMatrix, PrintOut=False):
    #sys.stdout.write('\n')

    for Stripe in StripeToBuildList: #erase all blocks
        block[Stripe] = bytearray(b'')

    ChangeMade = False
    Iteration = 1
    while True:
        ChangeMade = False
        if PrintOut: sys.stdout.write('   Stripe to rebuild number: '+ str(len(StripeToBuildList)) + '. Iteration=' + str(Iteration) + '\n')
        for Stripe in StripeToBuildList: 
            if len(block[Stripe]):
                if PrintOut: sys.stdout.write('       Already calculated: '+ Stripe + '\n')
                continue
                
            if PrintOut: sys.stdout.write('       Pattern to check number: '+ str(len(RuleMatrix)) + '\n')
            for Buildpattern in RuleMatrix:
                if Stripe in Buildpattern:
                    # if PrintOut: sys.stdout.write('           Stripe '+ Stripe + ' could be built from ' + str(Buildpattern) + '\n')
                    ValidRule = True
                    for RequiredStripe in Buildpattern:
                        if RequiredStripe != Stripe and len(block[RequiredStripe]) == 0:
                            if PrintOut: sys.stdout.write('           Stripe '+ Stripe + ' could be built from ' + str(Buildpattern) + ' but is missing  ' + RequiredStripe + '. Next Iteration maybe.\n')
                            # if PrintOut: sys.stdout.write('               Missing stripe '+ RequiredStripe + '. Next Iteration maybe.\n')
                            ValidRule = False
                            continue
                    if not ValidRule:
                        continue
                    if PrintOut: sys.stdout.write('           Stripe '+ Stripe + ' CAN BE built from ' + str(Buildpattern) + '\n')                    
                    # import binascii
                    # if PrintOut: sys.stdout.write('                RESULT  '+ binascii.hexlify(block[Stripe]) + ' len=' + str(len(block[Stripe]))+  '\n')
                    RebuildStripe (block, Stripe, Buildpattern) 
                    ChangeMade = True                    
                    # if PrintOut: sys.stdout.write('                RESULT  '+ binascii.hexlify(block[Stripe]) + ' len=' + str(len(block[Stripe]))+  '\n')
                    break                            
                else:
                    if PrintOut: sys.stdout.write('           Stripe '+ Stripe + ' could NOT be built from ' + str(Buildpattern) + '\n')
                    continue
        Iteration += 1
        if ChangeMade:
           continue            
        break
        
    Success = True
    for Stripe in StripeToBuildList: 
        if len(block[Stripe]) == 0:
            # sys.stdout.write('NOT ENOUGH REDUNDANCY. At least Stripe '+ str (StripeToBuildList) + ' could NOT be rebuilt\n')
            sys.stdout.write('NOT ENOUGH REDUNDANCY. Stripe '+ Stripe + ' could NOT be rebuilt\n')
            Success = False
    return Success
        
def RaidGenSplit (Filename, RaidType='', BlockSizeStr = DefaultBlockSize):

    if IsRaidTypeInvalid(RaidType): return

    BlockSize = int(BlockSizeStr)
    DataStripes    = ErrorCorrectionData[RaidType]['DataStripes']
    ErrCorrStripes = ErrorCorrectionData[RaidType]['ErrCorrStripes']
    RuleMatrix     = ErrorCorrectionData[RaidType]['RuleMatrix']
    WriteRotate    = ErrorCorrectionData[RaidType]['WriteRotate']

    sys.stdout.write('Splitting file ' + Filename + ' in ' + str(len(DataStripes)) + '+' + str(len(ErrCorrStripes)) + ' stripes using ' + RaidType + ' algoritm with a block size of ' + GetPrintableSize(BlockSize) + '.')    
    # create all file handlers
    InputFile = open(Filename, 'rb')    
    # block = []
    
    AllStripes = DataStripes + ErrCorrStripes
    AllStripesLen = len(AllStripes)
    
    StripeFile = {}
    for Stripe in AllStripes:
        StripeFile [Stripe] = open(GetStripeFilename(Filename, Stripe, BlockSize, RaidType), 'wb')
        # block.append('')
        # sys.stdout.write(       GetStripeFilename(Filename, Stripe, BlockSize, RaidType) + '\n')

    BlockNumber       = 0
    Distributor       = 0
    block = {}
    ReadingInProgress = True
    ReadingInProgress2 = True
    FirstStripe = DataStripes[0]
    LastStripe  = DataStripes[len(DataStripes)-1]
    while True:
        BlockNumber += 1
        # sys.stdout.write( 'Block ' + str(BlockNumber).rjust(4, '0') + ' (' + GetPrintableSize(len(DataStripes) * BlockNumber * BlockSize,PadLen=6) + '), read  stripe ' )
        for Stripe in DataStripes:
            block[Stripe] = bytearray(InputFile.read(BlockSize))
            if len(block[Stripe]) == 0 and Stripe == FirstStripe:  # it is empty and it is the first stripe
                sys.stdout.write( '\nEnd of file on first stripe. Finished.')
                BlockNumber -= 1
                ReadingInProgress = False
                break;
            if len(block[Stripe]) < BlockSize:
                # sys.stdout.write( ' only ' + str(len(block[Stripe])) + ' bites read. Padding to ' + str(BlockSize) +  ' BlockSize for stripe ' + Stripe) # + '\n')
                block[Stripe] = block[Stripe].ljust(BlockSize, b'\0')
                sys.stdout.write(  '*')                
                if Stripe == LastStripe:
                    ReadingInProgress2 = False
            # sys.stdout.write(  '' + Stripe + ',')                
            # sys.stdout.flush(  )
        sys.stdout.write( '\n' )
        if not ReadingInProgress:
            break
        
        Success = RaidGenRebuild (block , StripeToBuildList=ErrCorrStripes, RuleMatrix=RuleMatrix)    
            
        sys.stdout.write( 'Block ' + str(BlockNumber).rjust(4, '0') + ' (' + GetPrintableSize(len(DataStripes) * BlockNumber * BlockSize, PadLen=6) + '), write stripe ' )

        for StripeNumber in range(AllStripesLen):        
            Stripe = AllStripes[StripeNumber]
            StripeRotated = AllStripes[(StripeNumber + Distributor) % AllStripesLen]

            StripeFile[Stripe].write(block[StripeRotated])
            
            if WriteRotate:
                sys.stdout.write(  '' + Stripe + '<'+ StripeRotated + ',')
            else:
                sys.stdout.write(  '' + Stripe + ',')

        if WriteRotate:
            Distributor = BlockNumber % AllStripesLen
            
        if not ReadingInProgress2:
            break        
                
    sys.stdout.write( 'Written ' + str(BlockNumber) + ' blocks (' + GetPrintableSize(BlockNumber * BlockSize, PadLen=6) + ') in each stripe.\n')
    InputFile.close()

    # import pdb; pdb.set_trace()
    for Stripe in AllStripes:
        StripeFile[Stripe].close()

    with open(Filename + '-length.txt', 'w') as LenFile:
        LenFile.write(str(os.path.getsize(Filename)) + '\n')
        sys.stdout.write( 'File ' + Filename + ' has a size of ' + GetPrintableSize(os.path.getsize(Filename)) + '.\n')
        # sys.stdout.write( 'Written ' + str(BlockNumber) + ' blocks (' + GetPrintableSize(BlockNumber * BlockSize, PadLen=6) + ') in each stripe.\n')

    for Stripe in DataStripes + ErrCorrStripes:
        CheckMd5Hash (GetStripeFilename(Filename, Stripe, BlockSize, RaidType), ShortFileName='Stripe ' + Stripe, WriteHash='yes')
    CheckMd5Hash (Filename, WriteHash='yes')

def GetPrintableSize(BytesNum, PadLen = 1):
    if BytesNum < 1024:
        return ((str(BytesNum) + ' Bytes').rjust(PadLen, ' '))
    if BytesNum < 1048576:
        return ((str(BytesNum / 1024) + ' KB').rjust(PadLen, ' '))
    if BytesNum < 10485760:
        return (("%.1f" % (BytesNum / 1048576.0) + ' MB').rjust(PadLen, ' '))
        
    return ((str(BytesNum / 1048576) + ' MB').rjust(PadLen, ' '))

def CheckMd5Hash (Filename, ShortFileName='', WriteHash='no', PrintOut=True):
    # Hash = md5sum(Filename)
    # sys.stdout.write( 'File ' + Filename + ' has a checksum of ' + Hash + '.\n')
    # return Hash 
    
    if ShortFileName == '':
        ShortFileName = 'File ' + Filename
    
    HashValid = False    
    HashComputed = md5sum(Filename)

    if os.path.exists(Filename + '.md5'):
        try:
            with open(Filename + '.md5', 'r') as HashFile:
                HashRecorded = HashFile.read()
        except: 
            HashRecorded = "MissingChecksum"
        if WriteHash == 'yes':
            if PrintOut: sys.stdout.write( ShortFileName + ' has a checksum of ' + HashComputed + '. Checksum has been recorded.\n')
        elif HashRecorded == HashComputed:
            HashValid = True
            if PrintOut: sys.stdout.write( ShortFileName + ' has a checksum of ' + HashComputed + ' which matches the recorded one. Integrity is ok\n')
        else:
            if PrintOut: sys.stdout.write( ShortFileName + ' is corrupted. Checksum Computed=' + HashComputed + ', Recorded=' + HashRecorded + '.\n')
    else:        
        if WriteHash == 'ifmissing':
            if PrintOut: sys.stdout.write( ShortFileName + ' has a checksum of ' + HashComputed + '. Checksum file did not exist and has been recorded.\n')
            with open(Filename + '.md5', 'w') as HashFile:
                HashFile.write(HashComputed)
        elif WriteHash == 'yes':
            if PrintOut: sys.stdout.write( ShortFileName + ' has a checksum of ' + HashComputed + '. Checksum has been recorded.\n')
            with open(Filename + '.md5', 'w') as HashFile:
                HashFile.write(HashComputed)
        else:
            if PrintOut: sys.stdout.write( ShortFileName + ' has a checksum of ' + HashComputed + '. Checksum file does not exist.\n')
    return (HashValid)
            
def RaidGenCheckMd5 (Filename, RaidType='', BlockSizeStr = DefaultBlockSize, PrintOut=True):

    if IsRaidTypeInvalid(RaidType): return

    BlockSize = int(BlockSizeStr)
    
    DataStripes    = ErrorCorrectionData[RaidType]['DataStripes']
    ErrCorrStripes = ErrorCorrectionData[RaidType]['ErrCorrStripes']
    # RuleMatrix     = ErrorCorrectionData[RaidType]['RuleMatrix']
    # WriteRotate    = ErrorCorrectionData[RaidType]['WriteRotate']
    
    InvalidStripeList = []
    for Stripe in DataStripes + ErrCorrStripes:
        if not CheckMd5Hash (GetStripeFilename(Filename, Stripe, BlockSize, RaidType), ShortFileName='Stripe ' + Stripe, WriteHash='no', PrintOut=PrintOut):
            InvalidStripeList.append(Stripe)
    return InvalidStripeList

def GetStripeFilename(Filename, Stripe, BlockSize, RaidType):
    return (Filename + '-stripe-' + Stripe + '-' + RaidType + '-' + str(BlockSize)+ '.bin')

def RaidGenRebuildStripes (Filename, StripesToRebuild='', RaidType='', BlockSizeStr = DefaultBlockSize):

    if IsRaidTypeInvalid(RaidType): return

    BlockSize = int(BlockSizeStr)

    DataStripes    = ErrorCorrectionData[RaidType]['DataStripes']
    ErrCorrStripes = ErrorCorrectionData[RaidType]['ErrCorrStripes']
    RuleMatrix     = ErrorCorrectionData[RaidType]['RuleMatrix']
    WriteRotate    = ErrorCorrectionData[RaidType]['WriteRotate']

    MissingStripes=StripesToRebuild.split()
    
    AllStripes    = DataStripes + ErrCorrStripes
    AllStripesLen = len(AllStripes)

    # create all file handlers
    StripeFile = {}
    for Stripe in AllStripes:
        if Stripe in MissingStripes:
            StripeFile [Stripe] = open(GetStripeFilename(Filename, Stripe, BlockSize, RaidType), 'wb')
            sys.stdout.write(       GetStripeFilename(Filename, Stripe, BlockSize, RaidType) + ' - for write\n')
        else:
            StripeFile [Stripe] = open(GetStripeFilename(Filename, Stripe, BlockSize, RaidType), 'rb')
            sys.stdout.write(       GetStripeFilename(Filename, Stripe, BlockSize, RaidType) + ' - for read\n')
        # block.append('')

    BlockNumber = 0
    Distributor = 0
    block = {}
    ReadingInProgress = True
    CorrectionSuccess = True
    while True:
        block = {}    
        MissingStripesTemp=[]
        BlockNumber += 1
        sys.stdout.write( 'Block ' + str(BlockNumber).rjust(4, '0') + ' (' + GetPrintableSize(len(DataStripes) * BlockNumber * BlockSize, PadLen=6) + '), stripe ' )
        
        # for Stripe in AllStripes:
        for StripeNumber in range(AllStripesLen):
            Stripe = AllStripes[StripeNumber]
            StripeRotated = AllStripes[(StripeNumber + Distributor) % AllStripesLen]
            if Stripe in MissingStripes:
                MissingStripesTemp.append(StripeRotated)
                continue
                
            block[StripeRotated] = bytearray(StripeFile [Stripe].read(BlockSize))
            if len(block[StripeRotated]) == 0:  # it is empty and it is the first stripe
                sys.stdout.write( '\nEnd of file on stripe. Finished.')
                BlockNumber -= 1
                ReadingInProgress = False
                break;

            if WriteRotate:
                sys.stdout.write(  '' + Stripe + ' as '+ StripeRotated + ', ')                
            else:
                sys.stdout.write(  '' + Stripe + ',')                
            # sys.stdout.flush(  )

        sys.stdout.write( '\n' )
            
        if not ReadingInProgress:
            break

        Success = RaidGenRebuild (block , StripeToBuildList=MissingStripesTemp, RuleMatrix=RuleMatrix)
        if not Success: CorrectionSuccess = False

        for StripeNumber in range(AllStripesLen):
            Stripe = AllStripes[StripeNumber]
            StripeRotated = AllStripes[(StripeNumber + Distributor) % AllStripesLen]
            if Stripe in MissingStripes:
                StripeFile[Stripe].write(block[StripeRotated])
                # sys.stdout.write( 'Writing ' + str(block[StripeRotated]) + ' to ' + Stripe + '\n' )
                sys.stdout.write(  'Writing ' + Stripe + ', ')
            
        sys.stdout.write(  '\n')

        if WriteRotate:
            Distributor = BlockNumber % AllStripesLen
                
    sys.stdout.write( 'Written ' + str(BlockNumber) + ' blocks (' + GetPrintableSize(BlockNumber * BlockSize, PadLen=6) + ') in each stripe.\n')
    # import pdb; pdb.set_trace()
    for Stripe in AllStripes:
        StripeFile[Stripe].close()
        
    # import pdb; pdb.set_trace()
    
    
    for Stripe in MissingStripes:
        CheckMd5Hash (GetStripeFilename(Filename, Stripe, BlockSize, RaidType), ShortFileName='Stripe ' + Stripe, WriteHash='ifmissing')
        
    return(CorrectionSuccess)

def RaidGenRebuildFile(Filename, FilenameOut, RaidType='', BlockSizeStr = DefaultBlockSize):

    if IsRaidTypeInvalid(RaidType): return

    InvalidStripeList = RaidGenCheckMd5 (Filename, RaidType=RaidType, BlockSizeStr = BlockSizeStr, PrintOut=False)
    
    if len(InvalidStripeList)> 0:
        sys.stdout.write( '\nHouston we have corruption on stripes: ' + str(InvalidStripeList) + '. Let\'s attempt correction...\n')
        InvalidStripeListStr = str(InvalidStripeList).lstrip('[').rstrip(']').replace("'","").replace(",","")        
        CorrectionSuccess = RaidGenRebuildStripes (Filename, StripesToRebuild=InvalidStripeListStr, RaidType=RaidType, BlockSizeStr = BlockSizeStr)
        if not CorrectionSuccess:
            sys.stdout.write( '\nHouston, the corruption on stripes cannot be fixed\n')
            return (False)
    else:
        sys.stdout.write( '\nAll stripes are Ok. Integrity test passed\n')
    
    RaidGenBuildFile(Filename, FilenameOut, RaidType=RaidType, BlockSizeStr = BlockSizeStr)
    return (True)

def RaidGenBuildFile(Filename, FilenameOut, RaidType='', BlockSizeStr = DefaultBlockSize):

    if IsRaidTypeInvalid(RaidType): return

    BlockSize = int(BlockSizeStr)
    DataStripes    = ErrorCorrectionData[RaidType]['DataStripes']
    ErrCorrStripes = ErrorCorrectionData[RaidType]['ErrCorrStripes']
    RuleMatrix     = ErrorCorrectionData[RaidType]['RuleMatrix']
    WriteRotate    = ErrorCorrectionData[RaidType]['WriteRotate']

    sys.stdout.write( 'Rebuilding file ' + Filename + ' into ' + FilenameOut + ' from the following stripes:\n')
    #Open main file for writing
    OutputFile = open(FilenameOut, 'wb')

    AllStripes = DataStripes + ErrCorrStripes
    AllStripesLen = len(AllStripes)
    
    #Open stripes for reading     
    StripeFile = {}    
    for Stripe in AllStripes:
        StripeFile [Stripe] = open(GetStripeFilename(Filename, Stripe, BlockSize, RaidType), 'rb')
        sys.stdout.write(       GetStripeFilename(Filename, Stripe, BlockSize, RaidType) + '\n')
    
    # for Stripe in DataStripes:
        # StripeFile [Stripe] = open(GetStripeFilename(Filename, Stripe, BlockSize, RaidType), 'rb')
        # sys.stdout.write(       GetStripeFilename(Filename, Stripe, BlockSize, RaidType) + '\n')

    BlockNumber       = 0
    Distributor       = 0
    block = {}
    ReadingInProgress = True
    while True:
        BlockNumber += 1
        # sys.stdout.write( 'BlockNumber ' + str(BlockNumber).rjust(4, '0') + ': ') # + ', rebuilding file ' + Filename + '\n')
        sys.stdout.write( 'Block ' + str(BlockNumber).rjust(4, '0') + ' (' + GetPrintableSize(len(DataStripes) * BlockNumber * BlockSize, PadLen=6) + '): ' )

        for StripeNumber in range(AllStripesLen):
            Stripe = AllStripes[StripeNumber]
            StripeRotated = AllStripes[(StripeNumber + Distributor) % AllStripesLen]
            if StripeRotated in ErrCorrStripes:
                #MissingStripesTemp.append(StripeRotated)
                bytearray(StripeFile [Stripe].read(BlockSize))
                continue
                
            block[StripeRotated] = bytearray(StripeFile [Stripe].read(BlockSize))
            if len(block[StripeRotated]) == 0:  # it is empty 
                sys.stdout.write( '\nEnd of file on stripe. Finished.')
                BlockNumber -= 1
                ReadingInProgress = False
                break;

            if WriteRotate:
                sys.stdout.write(  '' + Stripe + ' as '+ StripeRotated + ', ')                
            else:
                sys.stdout.write(  '' + Stripe + ',')                
                
            # sys.stdout.flush(  )

        sys.stdout.write( '\n' )

        if not ReadingInProgress:
            break

        for Stripe in DataStripes:
            OutputFile.write(block[Stripe])                    
            sys.stdout.write(  'Writing ' + Stripe + ', ')
            # sys.stdout.flush(  )
        sys.stdout.write( '\n' )

        if WriteRotate:
            #Distributor = (Distributor + 1) % AllStripesLen
            Distributor = BlockNumber % AllStripesLen
            
    sys.stdout.write( 'Written ' + str(BlockNumber) + ' blocks (' + GetPrintableSize(BlockNumber * BlockSize * len(DataStripes), PadLen=6) + ') to file ' + FilenameOut + '\n')

    for Stripe in AllStripes:
        StripeFile[Stripe].close()
    
    with open(Filename + '-length.txt', 'r') as LenFile:
        FileLength = int(LenFile.read())

    OutputFile.truncate(FileLength)
    OutputFile.close()
        
    sys.stdout.write( 'File truncated to ' + GetPrintableSize(FileLength) + '\n')
    
    HashComputed = md5sum(FilenameOut)
    try:
        with open(Filename+ '.md5', 'r') as HashFile:
            HashRecorded = HashFile.read()
    except: 
        HashRecorded = "MissingChecksum"

    if HashRecorded == HashComputed:
        sys.stdout.write( 'File ' + FilenameOut + ' has a checksum of ' + HashComputed + '. Integrity is ok and matching checksum of ' + Filename  + '\n')
    else:
        sys.stdout.write( 'File ' + FilenameOut + ' is corrupted. Checksum Computed=' + HashComputed + ', Recorded checksum of ' + Filename + ' is ' + HashRecorded + '.\n')

def IsRaidTypeInvalid(RaidType):
    if RaidType in ErrorCorrectionData.keys():
        return False

    sys.stdout.write('Invalid RaidType: ' + RaidType + '\n')
    sys.stdout.write('Valid RaidType are: ' )
    for k in ErrorCorrectionData.keys():
        sys.stdout.write(k + ', ' )
    sys.stdout.write('\n')
    return True
    
def main():
    if len(sys.argv) <2:
        sys.stdout.write('Usage:\n')
        sys.stdout.write('    RaidLib Create | Check | RebuildStripe | BuildFile | RebuildFile | PrintMd5\n')
        return

    Commands = {}
    Commands['create'] = {
        'MinArgs' : 1,
        'Usage' : '<Filename> <RaidType> <BlockSize>',
        'Function' : RaidGenSplit        
    }
    Commands['check'] = {
        'MinArgs' : 1,
        'Usage' : '<Filename> <RaidType> <BlockSize>',
        'Function' : RaidGenCheckMd5        
    }
    Commands['rebuildstripe'] = {
        'MinArgs' : 2,
        'Usage' : '<Filename> "<StripesToRebuild>" <RaidType> <BlockSize>',
        'Function' : RaidGenRebuildStripes    
    }
    Commands['buildfile'] = {
        'MinArgs' : 2,
        'Usage' : '<Filename> <FilenameOut> <RaidType> <BlockSize>',
        'Function' : RaidGenBuildFile
    }
    Commands['rebuildfile'] = {
        'MinArgs' : 2,
        'Usage' : '<Filename> <FilenameOut> <RaidType> <BlockSize>',
        'Function' : RaidGenRebuildFile
    }
    Commands['printmd5'] = {
        'MinArgs' : 1,
        'Usage' : '<Filename>\n',
        'Function' : CheckMd5Hash        
    }

    if sys.argv[1].lower() in Commands:
        if len(sys.argv) < Commands[sys.argv[1].lower()]['MinArgs']+2 :
            sys.stdout.write('Usage:\n')
            sys.stdout.write('    RaidLib ' + sys.argv[1].lower() + ' ' + Commands[sys.argv[1].lower()]['Usage'] + '\n')
            sys.stdout.write('    where RaidType can be: ' )
            for k in ErrorCorrectionData.keys():
                sys.stdout.write(k + ', ' )
            sys.stdout.write('\n')
            return
        if len(sys.argv) == 3:            
            Commands[sys.argv[1].lower()]['Function'](sys.argv[2])
        if len(sys.argv) == 4:            
            Commands[sys.argv[1].lower()]['Function'](sys.argv[2], sys.argv[3])
        if len(sys.argv) == 5:            
            Commands[sys.argv[1].lower()]['Function'](sys.argv[2], sys.argv[3], sys.argv[4])
        if len(sys.argv) == 6:            
            Commands[sys.argv[1].lower()]['Function'](sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5])
        if len(sys.argv) == 7:            
            Commands[sys.argv[1].lower()]['Function'](sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6])
        return
    
    sys.stdout.write('RaidLib: Invalid command\n')
    return 
    

if __name__ == "__main__":
    main()
        
